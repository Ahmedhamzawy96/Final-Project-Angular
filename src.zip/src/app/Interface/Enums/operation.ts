export enum Operation {
  Expense = 0,
  ImportReciept = 1,
  ExportReciept = 2,
  CarTrans = 3,
  SuppplierTrans = 4,
  CustomerTrans = 5,
}
