export enum TransType {
  Paid = 0,
  Get = 1,
}
