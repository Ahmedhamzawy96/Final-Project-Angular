export enum AccountType {
  Customer = 0,
  Supplier = 1,
  Car = 2,
  Treasure=3
}
