export enum UserType {
  Admin = 0,
  Employee = 1,
  Car = 2,
}
