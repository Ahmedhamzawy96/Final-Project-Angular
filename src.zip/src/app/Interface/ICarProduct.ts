export interface ICarProduct
{
  quantity:Number,
  carID:number,
  productID:number,
  productName?:string
}
