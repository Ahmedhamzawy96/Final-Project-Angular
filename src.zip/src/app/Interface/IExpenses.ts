export interface IExpenses{
  id?:Number,
  name:string
}
