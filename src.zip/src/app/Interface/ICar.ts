
export interface ICar
{
  id:Number,
  name:string,
  account:Number,
  notes: string
  }
