export interface ISupplier{
  id:Number,
  name:string,
  phone:string,
  account:Number,
  notes: string
}




