export interface IUsers{

  userName:string,
  password:string,
  type:number,
  carID?:number,
  carName?:string
}

