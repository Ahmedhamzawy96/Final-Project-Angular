export interface reportTotal {
    paid: number;
    get: number;
    dif: number;
    total: number;

}
