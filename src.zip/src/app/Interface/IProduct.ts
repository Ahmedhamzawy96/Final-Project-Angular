export interface IProduct{

  id:Number,
  name:string,
  buyingPrice:number,
  sellingPrice:number,
  quantity:number
}

