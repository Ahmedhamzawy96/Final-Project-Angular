export interface IImportProduct{

  importReceiptID?:Number,
  productID:number
  productName:string,
  quantity:number,
  totalPrice:number,
  buyingPrice:number,
}
