
export interface ICustomer{
  id?:Number,
  name:string,
  phone:string,
  account:Number,
  notes: string,
}

