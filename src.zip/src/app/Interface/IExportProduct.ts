export interface IExportProduct{
  
  exportRecieptID?:Number,
  productName:string,
  productID:Number
  quantity:number,
  totalPrice:number,
  productPrice:number,
}
