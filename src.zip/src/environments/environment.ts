export const environment = {
  production: false,
  APIUrl: 'http://localhost:5187/api',
};
