export const environment = {
  production: true,
  APIUrl: 'http://abdallahmaher-001-site1.atempurl.com/api',
};
